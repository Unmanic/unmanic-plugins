
**<span style="color:#56adda">0.0.7</span>**
- Fix plugin when run along side another plugin that moves or removes the source file

**<span style="color:#56adda">0.0.6</span>**
- Add support for Bash script inputs in the plugin settings
- Add support for Python script inputs in the plugin settings
- Add support for NodeJS script inputs in the plugin settings
- Add support for installing custom dependencies for NodeJS and Python scripts
- Remove support for Unmanic v1 PluginHandler compatibility

**<span style="color:#56adda">0.0.5</span>**
- Fix issue with the replace of {source_file_size}

**<span style="color:#56adda">0.0.4</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.3</span>**
- FIX: The format_map function can cause issues with some command or arg strings

**<span style="color:#56adda">0.0.2</span>**
- Refactor for Unmanic v1 PluginHandler compatibility

**<span style="color:#56adda">0.0.1</span>**
- initial version
