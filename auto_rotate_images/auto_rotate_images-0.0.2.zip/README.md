# Auto Rotate Images

plugin for [Unmanic](https://github.com/Unmanic)
