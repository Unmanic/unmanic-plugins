
**<span style="color:#56adda">0.0.4</span>**
- Improve workflow to remove additional file movements
- Update Plugin to remove Unmanic v1 PluginHandler compatibility
- Add ability to fail the task straight away from the worker process
- Add worker logs for when running on Unmanic v0.2.1+
- Add file comparison to mark a file as failed if it ends up being unchanged
- Improve description document for configuration of this plugin

**<span style="color:#56adda">0.0.3</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.2</span>**
- Add postprocessor and library file test runners to mark a file as failed and prevent it from being re-added
- Fix file copy issue for worker runner

**<span style="color:#56adda">0.0.1</span>**
- Initial version
