

In the plugin settings, specify a 'Search String'.

The plugin will search the files to find matching subtitle tracks.

The matching subtitle tracks will be moved to the 1st subtitle track.


Examples of search strings:

- 'en'
- 'fr'
- 'de'
