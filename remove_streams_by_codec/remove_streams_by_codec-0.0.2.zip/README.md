# Unmanic remove streams based on codec

This is a plugin for [Unmanic](https://docs.unmanic.app/)

Removes any streams that match configured codecs.

You can specify a comma seperated list of codecs, and any streams that use one of those codecs will be removed.
