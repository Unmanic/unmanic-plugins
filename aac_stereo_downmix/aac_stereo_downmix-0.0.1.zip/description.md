
---


##### Description:

This Plugin will downmix all audiotracks to stereo and encode them in AAC.

The default formula seems to work well but feel free to experiment.

---
###### Note:
This plugin was developed with ffmpeg version 5.1.3-Jellyfin - it may not work with other versions.